package proclient.event;

public enum EventDirection {

    OUTGOING,
    INCOMING;

}
