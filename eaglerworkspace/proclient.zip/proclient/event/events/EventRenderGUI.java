package proclient.event.events;

import net.minecraft.client.gui.ScaledResolution;
import proclient.event.Event;

public class EventRenderGUI extends Event<EventRenderGUI> {
    public ScaledResolution sr;

    public EventRenderGUI(ScaledResolution sr) {
        this.sr = sr;
    }
}