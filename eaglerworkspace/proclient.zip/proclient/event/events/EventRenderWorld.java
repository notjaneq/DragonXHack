package proclient.event.events;

import proclient.event.Event;

public class EventRenderWorld extends Event<EventRenderWorld> {
}